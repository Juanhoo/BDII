﻿
namespace Gamayun.UI.Areas.Student.Models
{
    public class SignInOutDTO
    {
        public int Id { get; set; }
    }
}
