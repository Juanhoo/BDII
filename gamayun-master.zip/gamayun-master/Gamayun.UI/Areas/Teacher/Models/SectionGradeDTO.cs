﻿namespace Gamayun.UI.Areas.Teacher.Models
{
    public class SectionGradeDTO
    {
        public int Id { get; set; }
        public int? Grade { get; set; }
    }
}
