﻿namespace Gamayun.UI.Utilities
{
    public static class Icons
    {
        public static string Admin => "far fa-address-card";
        public static string Teacher => "fas fa-chalkboard-teacher";
        public static string Student => "fas fa-user-graduate";
    }
}
