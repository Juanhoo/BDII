﻿namespace Gamayun.Infrastucture.Query
{
    public interface IGridQuery
    {
    }
}
