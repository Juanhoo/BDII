﻿namespace Gamayun.Infrastucture.Entities
{
    public enum SectionState
    {
        Created,
        Active,
        Closed,
        Canceled
    }
}