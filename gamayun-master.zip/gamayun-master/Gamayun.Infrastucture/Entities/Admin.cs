﻿namespace Gamayun.Infrastucture.Entities
{
    public class Admin : UserWithRole
    {
    }
}