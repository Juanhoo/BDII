﻿namespace Gamayun.Infrastucture.Command
{

    public interface ICommand
    {
    }
}
