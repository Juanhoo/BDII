﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gamayun.Infrastucture.Grid
{
    public class GridAction
    {
        public string Title { get; set; }
        public string JsFunction { get; set; }
    }
}
