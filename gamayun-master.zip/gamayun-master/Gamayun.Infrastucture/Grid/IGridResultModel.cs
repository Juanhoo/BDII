﻿namespace Gamayun.Infrastucture.Grid
{
    public interface IGridResultModel
    {
        int Id { get; }
    }
}
