﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Gamayun.Infrastucture.Grid
{
    public class GridProperty
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Title { get; set; }
        public bool Filter { get; set; }
    }
}
